# 😀 RF24_EncodeRadioDetails

### Description

An example demonstrating how to get and display debug information from nRF24L01 radios on the Arduino Uno Q using both Arduino & Python


### Additional RF24 Examples

See other examples at <https://github.com/TMRh20/Sketches/tree/master/ArduinoQ>.